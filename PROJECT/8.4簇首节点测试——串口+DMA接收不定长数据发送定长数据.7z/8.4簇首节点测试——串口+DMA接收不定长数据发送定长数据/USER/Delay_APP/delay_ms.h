#ifndef __DELAY_MS_H
#define __DELAY_MS_H
#include "stm32f0xx.h"
void delay_ms(uint16_t time);
void delay_us(uint16_t ulCount);
#endif
