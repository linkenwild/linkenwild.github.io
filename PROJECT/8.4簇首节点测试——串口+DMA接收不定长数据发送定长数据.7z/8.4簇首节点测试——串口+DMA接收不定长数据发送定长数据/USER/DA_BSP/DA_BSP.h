#ifndef __DA_BSP_H
#define __DA_BSP_H
#include "stm32f0xx.h"
/* �������� ------------------------------------------------------------------*/
void DMA_MemoryToPeripheral(uint32_t MemoryAddr, uint32_t PeripheralAddr, uint16_t BufferSize);
//void DMA_PeripheralToMemory(uint32_t PeripheralAddr, uint32_t MemoryAddr, uint16_t BufferSize);
#endif
