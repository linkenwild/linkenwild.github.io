#ifndef __PID_CONTROL_H
#define __PID_CONTROL_H
#include "stm32f0xx.h"
extern int PoN;
extern uint8_t MAsf;
uint16_t PID_algorithm(int16_t exp, int16_t KP, int16_t TI, int16_t TD);
#endif
