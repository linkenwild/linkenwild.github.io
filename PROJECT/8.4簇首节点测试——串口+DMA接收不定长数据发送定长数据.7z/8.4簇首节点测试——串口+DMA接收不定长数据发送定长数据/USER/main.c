#include "stm32f0xx.h"
#include "usb_usart1.h"
#include "delay_ms.h"
#include "DA_BSP.h"
#define  DATA_LEN                 50
extern uint32_t time;
uint8_t  Test_Buf[DATA_LEN];
uint8_t  Receive_Buf[DATA_LEN];
extern uint8_t Usart_Rx_Sta;
extern uint32_t Receive_buff_length;
int k;
int main(void)  
{	
	BSP_Initializes();
	USART_Initializes();
	while(1)
	{
//    /* ���� */
//    DMA_PeripheralToMemory((uint32_t)(&(USART1->RDR)), (uint32_t)Test_Buf, DATA_LEN);
//    while(!DMA_GetFlagStatus(DMA1_IT_TC3))
//    {                                            //�ȴ��������
//    }
//    DMA_ClearFlag(DMA1_IT_GL3);                  //�����־λ

    /* ���� */
		if((time>1)&&(Usart_Rx_Sta==0x03))
		{for(k=0;k<Receive_buff_length+1;k++)
		{
			Test_Buf[k]=Receive_Buf[k]+2;
		}
		Test_Buf[Receive_buff_length]=0x99;
    DMA_MemoryToPeripheral((uint32_t)Test_Buf, (uint32_t)(&(USART1->TDR)), Receive_buff_length+1);
    while(!DMA_GetFlagStatus(DMA1_IT_TC2))
    {                                            //�ȴ��������
    }
    DMA_ClearFlag(DMA1_IT_GL2);                  //�����־λ
		Usart_Rx_Sta=0;
		}		
	}
}
